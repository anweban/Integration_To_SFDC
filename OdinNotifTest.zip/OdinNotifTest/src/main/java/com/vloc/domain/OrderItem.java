package com.vloc.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class OrderItem {
	private static final String nsp = "koushik_107_1__";
	@JsonProperty(value="Id")
	String id;
	@JsonProperty(value="Name")
	String name;
	@JsonProperty(value=nsp + "FulfilmentStatus__c")
	String fulfilmentStatus;
	@JsonProperty(value=nsp + "SupplementalAction__c")
	String supplementalAction;
	@JsonProperty(value=nsp + "SupersededOrderItemId__c")
	String supersededOrderItemId;
	@JsonProperty(value="Product2Id")
	String product2Id;
	
	public String getId() { return id; }
	public void setId(String id) { this.id = id; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public String getFulfilmentStatus() { return fulfilmentStatus; }
	public void setFulfilmentStatus(String status) {
		this.fulfilmentStatus = status;
		}
	public String getSupplementalAction() { return supplementalAction; }
	public void setSupplementalAction(String status) {
		this.supplementalAction = status;
		}
	public String getSupersededOrderItemId() {
		return supersededOrderItemId;
		}
	public void setSupersededOrderItemId(String supersededOrderItemId) {
		this.supersededOrderItemId = supersededOrderItemId;
		}
	public String getProduct2Id() { return product2Id; }
	public void setProduct2Id(String product2Id) { this.product2Id = product2Id; }
	
}
