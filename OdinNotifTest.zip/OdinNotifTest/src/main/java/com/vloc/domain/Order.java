package com.vloc.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Order {
	private static final String nsp = "koushik_107_1__";
	@JsonProperty(value="Id")
	String id;
	@JsonProperty(value="Name")
	String name;
	@JsonProperty(value="Status")
	String status;
	@JsonProperty(value=nsp+"SupersededOrderId__c")
	String supersededOrderId;
	@JsonProperty(value=nsp + "FulfilmentStatus__c")
	String fulfilmentStatus;
	@JsonProperty(value=nsp + "OrderStatus__c")
	String orderStatus;
	@JsonProperty(value=nsp + "ChangeType__c")
	String changeType;
	
	@JsonProperty(value=nsp + "IsChangesAllowed__c")
	Boolean isChangesAllowed;
	@JsonProperty(value=nsp + "IsChangesAccepted__c")
	Boolean isChangesAccepted;
	
	public String getId() { return id; }
	public void setId(String id) { this.id = id; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public String getStatus() { return status; }
	public void setStatus(String status) { this.status = status; }
	public String getSupersededOrderId() { return supersededOrderId; }
	public void setSupersededOrderId(String supersededOrderId) { this.supersededOrderId = supersededOrderId; }
	public String getFulfilmentStatus() { return fulfilmentStatus; }
	public void setFulfilmentStatus(String fulfilmentStatus) { this.fulfilmentStatus = fulfilmentStatus; }
	public String getChangeType() { return changeType; }
	public void setChangeType(String changeType) { this.changeType = changeType; }
	public String getOrderStatus() { return orderStatus; }
	public void setOrderStatus(String orderStatus) { this.orderStatus = orderStatus; }
	
	public Boolean getIsChangesAllowed() { return isChangesAllowed; }
	public void setIsChangesAllowed(Boolean isChangesAllowed) { this.isChangesAllowed = isChangesAllowed; }
	public Boolean getIsChangesAccepted() { return isChangesAccepted; }
	public void setIsChangesAccepted(Boolean isChangesAccepted) { this.isChangesAccepted = isChangesAccepted; }
	
}
