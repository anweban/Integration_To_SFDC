import java.util.List;

import com.force.api.ApiConfig;
import com.force.api.ForceApi;
import com.force.api.QueryResult;
import com.vloc.domain.Order;
import com.vloc.domain.OrderItem;

public class GenerateWholeOrderPayload {
	private static final String nsp = "koushik_107_1__";
	
	public static void main(String[] args) {
		String orderId = "8013j000001u3Eo";
		//String state = "Accepted";
		String state = "Rejected";
	
		System.out.println("Attempting to connect to the org.");
		ForceApi api = new ForceApi(new ApiConfig().setUsername("koushik_107_1@vlocity.com").setPassword("Market425"));
		System.out.println("Connected successfully.");
		
		StringBuilder buf = new StringBuilder();
		
		QueryResult<OrderItem> oIQueryResult = api.query(
				"SELECT Id, "
		         + nsp + "FulfilmentStatus__c, Product2Id FROM OrderItem WHERE OrderId = \'"
						+ orderId + "\'", OrderItem.class);
		buf.append("[");
		buf.append("{");
		buf.append("\"orderId\": \"" + orderId +"\", \"state\": \"" + state + "\"");
		if (state.equalsIgnoreCase("Rejected")) {
			buf.append(",\"reasonCode\": \"PONR\", \"reasonDescription\": \"Point of No Return reached.\"");
		}
		buf.append("}");
		List<OrderItem> oiList = oIQueryResult.getRecords();
		for (OrderItem oneOI : oiList) {
			buf.append(",{");
			buf.append("\"orderItemId\": \"" + oneOI.getId() +"\", \"state\": \"" + state + "\"");
			if (state.equalsIgnoreCase("Rejected")) {
				buf.append(",\"reasonCode\": \"PONR\", \"reasonDescription\": \"Point of No Return reached.\"");
			}
			buf.append("}");
		}
		buf.append("]");
		System.out.println("Successfully created " + state + " payload.");
		System.out.println(buf.toString());
		System.out.println("Done.");
	}

}
