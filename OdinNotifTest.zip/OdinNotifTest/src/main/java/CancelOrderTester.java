/**
 * 
 * @author koushikrajagopalan
 *
 */
public class CancelOrderTester {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String cartId = "8016g000000L3INAA0";
		String itemIdToCancel = "8026g000000c2v6AAA";
		String request = "{\"cartId\": \"" + cartId + "\", ";
		request += "\"itemIds\" : [ \"" + itemIdToCancel + "\" ],";
		request +=" \"methodName\": \"cancelItems\"}";
		System.out.println(request);
	}

}
