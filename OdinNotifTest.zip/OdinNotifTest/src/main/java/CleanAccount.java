import java.util.List;

import com.force.api.ApiConfig;
import com.force.api.ForceApi;
import com.force.api.QueryResult;
import com.vloc.domain.Account;
import com.vloc.domain.Asset;
import com.vloc.domain.Order;
public class CleanAccount {

	public static void main(String[] args) {
		String accountId = "0013j00002a2JUn";
		System.out.println("Attempting to connect to the org.");
		ForceApi api = new ForceApi(new ApiConfig().setUsername("koushik_107_1@vlocity.com").setPassword("Market425"));
		//Account acc = api.getSObject("Account", "0013i000008MguO").as(Account.class);
		System.out.println("Connected successfully.");
		System.out.println("Attempting to clean up Orders.");
		// Get All Orders
		String orderQuery = "SELECT Id FROM Order WHERE AccountId = \'" + accountId + "\'";
		QueryResult<Order> queriedOrders = api.query(orderQuery, Order.class);
		if (queriedOrders == null) {
			System.out.println("queriedOrders is null");
		} else {
			System.out.println("queriedOrders.size() = " + queriedOrders.getTotalSize());
		}
		if (queriedOrders != null && queriedOrders.getTotalSize() > 0) {
			System.out.println("Found " + queriedOrders.getTotalSize() + " of Orders.");
			List<Order> orderList = queriedOrders.getRecords();
			// Deactivate all Orders
			Order tempOrder = new Order();
			tempOrder.setStatus("Draft");
			for (Order oneOrder : orderList) {
				try {
				api.updateSObject("Order", oneOrder.getId(), tempOrder);
				} catch(Exception ex) {
					System.out.println("Error happened while updating Order with Id: " + oneOrder.getId());
					ex.printStackTrace();
				}
			}
			
			// Delete all orders
			for (Order oneOrder : orderList) {
				api.deleteSObject("Order", oneOrder.getId());
			}
		} else {
			System.out.println("No orders found - to update and delete.");
		}
		System.out.println("----");
		System.out.println("Done with clean up of orders.");
		System.out.println("Attempting to clean up Assets.");
		// Delete all assets
		QueryResult<Asset> queriedAssets = api.query("SELECT Id FROM Asset WHERE AccountId = \'" + accountId + "\'", Asset.class);
		if (queriedAssets != null && queriedAssets.getTotalSize() > 0) {
			List<Asset> assetList = queriedAssets.getRecords();
			for (Asset oneAsset : assetList) {
				System.out.println("Deleting asset with Id: " + oneAsset.getId());
				try {
					api.deleteSObject("Asset", oneAsset.getId());
				} catch(Exception ex) {
					System.out.println("Asset with Id " + oneAsset.getId() + " is not deleted because it is probably already deleted");
					
				}
			}
		} else {
			System.out.println("No Asset(s) found - to delete");
		}
		System.out.println("----");
		System.out.println("Done");
	}

}
