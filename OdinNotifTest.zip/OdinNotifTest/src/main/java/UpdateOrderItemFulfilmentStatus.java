import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.force.api.ApiConfig;
import com.force.api.ForceApi;
import com.force.api.QueryResult;
import com.vloc.domain.Order;
import com.vloc.domain.OrderItem;

public class UpdateOrderItemFulfilmentStatus {
	private static final String nsp = "koushik_107_1__";
	public static void main(String[] args) {
		
		String orderId = "8013j000001u3Eo";
		String typeOfChange = "Cancel";
		System.out.println("Attempting to connect to the org.");
		ForceApi api = new ForceApi(new ApiConfig().setUsername("koushik_107_1@vlocity.com").setPassword("Market425"));
		//Account acc = api.getSObject("Account", "0013i000008MguO").as(Account.class);
		System.out.println("Connected successfully.");
		
		Order supplementalOrder = api.getSObject("Order", orderId).as(Order.class);
		String originalOrderId = supplementalOrder.getSupersededOrderId();
		System.out.println("Attempting to get all order items for order: " + orderId + ".");
		
		
		QueryResult<OrderItem> oIQueryResult = api.query(
				"SELECT Id, "
		         + nsp + "FulfilmentStatus__c, Product2Id FROM OrderItem WHERE OrderId = \'"
						+ orderId + "\'", OrderItem.class);
		List<OrderItem> oiList = oIQueryResult.getRecords();
		System.out.println("Attempting to get all order items for order: " + originalOrderId + ".");
		Map<String, OrderItem> supplementalOIByProduct2IdMap = new HashMap<String, OrderItem>();
		
		
		QueryResult<OrderItem> origOIQueryResult = api.query(
				"SELECT Id, "
		         + nsp + "FulfilmentStatus__c, Product2Id FROM OrderItem WHERE OrderId = \'"
						+ originalOrderId + "\'", OrderItem.class);
		List<OrderItem> origOIList = origOIQueryResult.getRecords();
		Map<String, OrderItem> origOIByProduct2IdMap = new HashMap<String, OrderItem>();
		for (OrderItem oneOI : origOIList) {
			origOIByProduct2IdMap.put(oneOI.getProduct2Id(), oneOI);
		}
		OrderItem tempOI = new OrderItem();
		tempOI.setSupplementalAction(typeOfChange);
		tempOI.setFulfilmentStatus("In Progress");
		System.out.println("Attempting to update all order items for order: " + orderId + ".");
		for (OrderItem oneOI : oiList) {
			OrderItem originalOI = origOIByProduct2IdMap.get(oneOI.getProduct2Id());
			tempOI.setSupersededOrderItemId(originalOI.getId());
			api.updateSObject("OrderItem", oneOI.getId(), tempOI);
			supplementalOIByProduct2IdMap.put(oneOI.getProduct2Id(), oneOI);
		}
		Order tempOrder = new Order();
		tempOrder.setChangeType(typeOfChange);
		tempOrder.setFulfilmentStatus("In Progress");
		tempOrder.setOrderStatus("In Progress");
		System.out.println("Attempting to update order: " + orderId + ".");
		api.updateSObject("Order", supplementalOrder.getId(), tempOrder);
		
		System.out.println("Done with all updates.");
	}

}
