import java.util.ArrayList;
import java.util.List;

public class Combinations {

	public static void main(String[] args) {
		List<String> statusList = new ArrayList<String>() {{
			add("Draft");
			add("Activated");
		}};
		List<String> orderStatusList = new ArrayList<String>() {{
			add("Ready To Submit");
			add("In Progress");
			add("Submitted");
			add("Rejected");
			add("Amend Requested");
			add("Cancel Requested");
			add("Cancel In Progress");
			add("Complete");
			add("Cancelled");
			add("Queued");
			add("Frozen");
			add("Superseded");
			add("Activated");
		}};
		List<String> supplementalActionList = new ArrayList<String>() {{
			add("Amend");
			add("Cancel");
			add("Follow On");
			add(null);
		}};
		for (String oneStatus : statusList) {
			for (String oneOrdStatus : orderStatusList) {
				for (String oneSuppleAction : supplementalActionList) {
					System.out.println(oneStatus + "," + oneOrdStatus + "," + oneSuppleAction);
				}
			}
		}
	}

}
