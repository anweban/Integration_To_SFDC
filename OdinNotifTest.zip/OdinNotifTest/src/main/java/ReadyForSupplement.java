import com.force.api.ApiConfig;
import com.force.api.ForceApi;
import com.vloc.domain.Order;

public class ReadyForSupplement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String orderId = "8013j000001u3Ej";
		Order ord = new Order();
		ord.setOrderStatus("In Progress");
		ord.setFulfilmentStatus("In Progress");
		ord.setOrderStatus("In Progress");
		ord.setStatus("Draft");
		ord.setIsChangesAllowed(true);
		
		System.out.println("Attempting to connect to the org.");
		ForceApi api = new ForceApi(new ApiConfig().setUsername("koushik_107_1@vlocity.com").setPassword("Market425"));
		//Account acc = api.getSObject("Account", "0013i000008MguO").as(Account.class);
		System.out.println("Connected successfully.");
		
		api.updateSObject("Order", orderId, ord);
		System.out.println("Successfully updated the order.");
		System.out.println("Done.");
	}

}
